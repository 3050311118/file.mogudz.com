<!-- http://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=QTXBBa1huJdOD3RuorvxfrZv9PQBtAhxiYRR1TnA3kUYKVGCOFhHP_fZt7hzWznGH0QVGsmRCtGIZZ1T6jG8om__6Y1n1MwdsC9RoAkU9DXYNr1a8yKKWLOBTZhUPu76VLJhAJAZPN -->
<!-- http://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=ACCESS_TOKEN -->
<?php
require_once "jssdk.php";
$jssdk = new JSSDK("wx5de1ab48fc31328f", "5bccc90e29a6dbfa5cf795bb88477d22");
$signPackage = $jssdk->GetSignPackage();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>我的在线设备</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
  <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="weui.css">
    <link rel="stylesheet" href="example1.css"/>
    <script src="mqttws31.js" type="text/javascript"></script>  
    <script src="zepto.min.js" type="text/javascript"></script> 
    <script src="core-min.js"></script>
    <script src="enc-base64.js"></script>    
    <script src="myjs.js"></script>
    <script src="vue.min.js"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
    <script type="text/javascript"> 
    function goto(url,name){
       localStorage.setItem('tempdev',url)
       localStorage.setItem('tempname',name)
       window.location.href="http://a3050311118.gicp.net/jssdk/dev_"+url+".php#navbar"
    }

    function onMessageArrived(message) {  
        var topic = message.destinationName;  
        var payload = message.payloadString;  
        var words = CryptoJS.enc.Base64.parse(payload);
        var parseStr = words.toString(CryptoJS.enc.Utf8);
        var json = JSON.parse(parseStr)
        if(json.t === "bdok"){
            jsonop(devlist,json.i,json.m)
            myvue.setData=devlist
        }else if(json.t === "online"){
            jsonop(devlist,json.n,json.m)
            jsonop(devlist,"")
            myvue.setData=devlist
            $("#loading").text("刷新设备")
        }
    }   
    $(document).ready(function(){
        MQTTconnect(1);
    });
    </script>  
</head>
<body ontouchstart="">
  <div id="app">
        <div class="weui-cells__title">我的在线设备</div>     
        <div v-for="(value, key) in devlist">
        <div class="weui-cells">
            <a class="weui-cell weui-cell_access" onclick="goto('{{key}}','{{value}}')" href="javascript:void(0)">
                <div class="weui-cell__bd">
                    <p>{{key}}</p>
                </div>
                <div class="weui-cell__ft">{{value}}</div>
            </a>
        </div>
        </div>
<br>        
    <a href="javascript:rescan();" id="scan" class="weui-btn weui-btn_primary weui-btn_loading"><i id="loading" class="weui-loading"></i>正在加载</a>    
<br><button class="btn btn_primary" id="scancode">扫码绑定</button>
    </div>
</body>
<script>
  wx.config({
    beta: true,
    // debug: true,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: <?php echo $signPackage["timestamp"];?>,
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: [
      'hideMenuItems',
      'getNetworkType',
      'scanQRCode'
      ]
    });
    wx.ready(function() {
      wx.hideOptionMenu();
      $("#scancode").click(function(){
        wx.scanQRCode({
          needResult: 1,
          desc: 'scanQRCode desc',
          success: function (res) {
            var arr={};
            arr.t="wxbd";
            arr.i=openid;   
            arr.s="wx";           
            MqttSend(res.resultStr+'/sub',JSON.stringify(arr));
          }
        });
      })
    });

    wx.error(function(res) {
      alert(res.errMsg);
    });

    function rescan(){
        var arr={"t":"online","i":openid}
        MqttSend(wxsubtopic,JSON.stringify(arr)); 
        $("#loading").addClass("weui-loading");
        $("#scan").html("正在加载");
        setTimeout(cancelScan,5000)     
    }
    function cancelScan(){
      $("#loading").removeClass("weui-loading");
      $("#scan").html("重新扫描");
    }

    var myvue=new Vue({
      el: '#app',
      data: {
        progress: 0,
        devlist:[]
      },
      created: function () {

      },
      computed: {
          setData: {
            set: function (data) {
              this.devlist = data
            }
          }
      }
    }) 
    $(document).ready(function(){
        setTimeout(cancelScan,5000)
        myvue.setData=json
    });
</script>
    <script src="zepto.min.js"></script>
    <script src="weui.min.js"></script>
    <script src="example1.js"></script>
</html>
