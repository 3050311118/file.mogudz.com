<?php
require_once "jssdk.php";
$jssdk = new JSSDK("wx5de1ab48fc31328f", "5bccc90e29a6dbfa5cf795bb88477d22");
$signPackage = $jssdk->GetSignPackage();
?>
<html>  
  <head>  
    <title>设备</title>  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="weui.css">
    <link rel="stylesheet" href="example1.css"/>
    <script src="mqttws31.js" type="text/javascript"></script>  
    <script src="zepto.min.js" type="text/javascript"></script> 
    <script src="core-min.js"></script>
    <script src="enc-base64.js"></script>    
    <script src="myjs.js"></script>
    <script src="weui.min.js"></script>
    <script src="vue.min.js"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
  </head> 
  <body >  
    <div class="weui-cells__title">输出状态</div>
    <div class="weui-grids">
        <a href="javascript:output(1);" id="o1" class="weui-grid">
            <p class="weui-grid__label" >输出1</p>
        </a>
        <a href="javascript:output(2);" id="o2" class="weui-grid">
            <p class="weui-grid__label" >输出2</p>
        </a>
        <a href="javascript:output(3);" id="o3" class="weui-grid">
            <p class="weui-grid__label" >输出3</p>
        </a>
        <a href="javascript:output(4);" id="o4" class="weui-grid">
            <p class="weui-grid__label" >输出4</p>
        </a>
    </div>
    <div class="weui-cells__title">输入状态</div>
    <div class="weui-grids">
        <a href="javascript:;" id="i1" class="weui-grid">
            <p class="weui-grid__label" >输入1</p>
        </a>
        <a href="javascript:;" id="i2" class="weui-grid">
            <p class="weui-grid__label" >输入2</p>
        </a>
        <a href="javascript:;" id="i3" class="weui-grid">
            <p class="weui-grid__label" >输入3</p>
        </a>
    </div><br>
    <button class="btn btn_primary" id="refresh">刷新</button> 
</body>  
<script>
      wx.config({
        beta: true,
        debug: false,
        appId: '<?php echo $signPackage["appId"];?>',
        timestamp: <?php echo $signPackage["timestamp"];?>,
        nonceStr: '<?php echo $signPackage["nonceStr"];?>',
        signature: '<?php echo $signPackage["signature"];?>',
        jsApiList: [
          'hideMenuItems',
          ]
        });
      wx.ready(function() {
        wx.hideOptionMenu();
      });
      wx.error(function(res) {
        alert("打开错误");
      });
      function onMessageArrived(message) {  
          var topic = message.destinationName;  
          var payload = message.payloadString;  
          var words = CryptoJS.enc.Base64.parse(payload);
          var parseStr = words.toString(CryptoJS.enc.Utf8);
          var json = JSON.parse(parseStr)
          if(json.t === "info"){
            $("#i1").css('background',json.i1?"grey":"blue")
            $("#i2").css('background',json.i2?"grey":"blue")
            $("#i3").css('background',json.i3?"grey":"blue")

            $("#o1").css('background',json.o1?"blue":"grey")
            $("#o2").css('background',json.o2?"blue":"grey")
            $("#o3").css('background',json.o3?"blue":"grey")
            $("#o4").css('background',json.o4?"blue":"grey")
          }
      }   
      $(document).ready(function(){
          document.title = ''+tempname;
          MQTTconnect(2);
          $("#refresh").click(function(){
              var arr={"t":"info","i":openid}
              MqttSend(wxdevtopic,JSON.stringify(arr));
          })
          $("[id^='o']").click(function(){
              var num=$(this).attr("id")
              var arr={"t":"ioset","i":openid,"o":num}
              MqttSend(wxdevtopic,JSON.stringify(arr));
          })
      });
</script>
</html>  