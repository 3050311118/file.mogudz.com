<?php
require_once "jssdk.php";
$jssdk = new JSSDK("wx5de1ab48fc31328f", "5bccc90e29a6dbfa5cf795bb88477d22");
$signPackage = $jssdk->GetSignPackage();
?>
<html>  
  <head>  
    <title>设备</title>  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="mqttws31.js" type="text/javascript"></script>  
    <script src="zepto.min.js" type="text/javascript"></script> 
    <script src="core-min.js"></script>
    <script src="enc-base64.js"></script>    
    <script src="myjs.js"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
    <script type="text/javascript">       

    $(document).ready(function(){
        // $("#head").attr("src", localStorage.getItem('headimgurl')); 
        // $("#name").text(localStorage.getItem('nickname'))
        MQTTconnect(2);
    });
    </script>  
  </head> 
  <body oncontextmenu=self.event.returnValue=false onselectstart="return false">  
    <img id="head"src=""/>
    <h5 id="name"> </h5>
    <h5 id="name"> </h5>
    <button class="btn btn_primary" id="translateVoice">开始录音</button>
    <button class="btn btn_primary" id="scancode">扫描二维码</button>
</body>  
<script>
    var clickCount=false;
    var voice = {
        localId: '',
        serverId: ''
    };
    function recordStart(){
        wx.startRecord({
          cancel: function () {
            alert('用户拒绝授权录音');
          }
        });
    }
    function recordStop(){
        wx.stopRecord({
            success: function (res) {
                wx.translateVoice({
                  localId: res.localId,
                  complete: function (res) {
                    if (res.hasOwnProperty('translateResult')) {
                      alert('识别结果：' + res.translateResult);
                    } else {
                      alert('无法识别');
                    }
                  }
                });
            },
            fail: function (res) {
                alert('识别失败');
            }
        });
    }
      wx.config({
        beta: true,
        debug: false,
        appId: '<?php echo $signPackage["appId"];?>',
        timestamp: <?php echo $signPackage["timestamp"];?>,
        nonceStr: '<?php echo $signPackage["nonceStr"];?>',
        signature: '<?php echo $signPackage["signature"];?>',
        jsApiList: [
          'hideMenuItems',
          'getNetworkType',
          'translateVoice',
          'startRecord',
          'stopRecord',
          'scanQRCode'
          ]
        });
      wx.ready(function() {
        wx.hideOptionMenu();
        $("#translateVoice").click(function(){
            if(clickCount === false){
                $("#translateVoice").text("开始识别")
                recordStart()
            }else{                
                $("#translateVoice").text("开始录音")
                recordStop()
            }
            clickCount=!clickCount;
        })
      });
      wx.error(function(res) {
        alert("打开错误");
      });
</script>
</html>  