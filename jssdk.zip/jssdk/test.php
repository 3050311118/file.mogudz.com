<?php
require_once "jssdk.php";
$jssdk = new JSSDK("wx5de1ab48fc31328f", "5bccc90e29a6dbfa5cf795bb88477d22");
$signPackage = $jssdk->GetSignPackage();
?>
<html>  
  <head>  
    <title>设备</title>  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="weui.css">
    <link rel="stylesheet" href="example1.css"/>
    <script src="mqttws31.js" type="text/javascript"></script>  
    <script src="zepto.min.js" type="text/javascript"></script> 
    <script src="core-min.js"></script>
    <script src="enc-base64.js"></script>    
    <script src="myjs.js"></script>
    <script src="weui.min.js"></script>
    <script src="vue.min.js"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
    <script type="text/javascript">     
    function submit(i){
      alert(""+i)
    }  
    $(document).ready(function(){
        // $("#head").attr("src", localStorage.getItem('headimgurl')); 
        // $("#name").text(localStorage.getItem('nickname'))
        MQTTconnect(2);
    });
    </script>  
  </head> 
  <body >  
<div id="app">
    {{message}}
</div>
</body>
<script type="text/javascript">
      var myvue=new Vue({
        el: '#app',
        data: {
          message: '菜鸟教程!'
        },
        created: function () {

        },
        computed: {
            setData: {
              set: function (data) {
                this.devlist = data
              }
            }
        }
      }) 
  //     var json={
  //   message: '菜鸟教程!'
  // }
      $(document).ready(function(){
          // myvue.setData=json
      });
</script>
</html>  