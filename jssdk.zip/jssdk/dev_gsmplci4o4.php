<?php
require_once "jssdk.php";
$jssdk = new JSSDK("wx5de1ab48fc31328f", "5bccc90e29a6dbfa5cf795bb88477d22");
$signPackage = $jssdk->GetSignPackage();
?>
<html>  
  <head>  
    <title>设备</title>  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="weui.min.css"/>
    <link rel="stylesheet" href="example.css"/>
    <script src="mqttws31.js" type="text/javascript"></script>  
    <script src="zepto.min.js" type="text/javascript"></script> 
    <script src="core-min.js"></script>
    <script src="enc-base64.js"></script>    
    <script src="myjs.js"></script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
    <script type="text/javascript">     
    function submit(i){
      alert(""+i)
    }  
    $(document).ready(function(){
        // $("#head").attr("src", localStorage.getItem('headimgurl')); 
        // $("#name").text(localStorage.getItem('nickname'))
        MQTTconnect(2);
    });
    </script>  
  </head> 
  <body oncontextmenu=self.event.returnValue=false onselectstart="return false">  
    <script type="text/html" id="tpl_navbar">
<div class="page">
    <div class="page__bd" style="height: 100%;">
        <div class="weui-tab">
            <div class="weui-navbar">
                <div class="weui-navbar__item weui-bar__item_on">
                    选项一
                </div>
                <div class="weui-navbar__item">
                    选项二
                </div>
                <div class="weui-navbar__item">
                    选项三
                </div>
            </div>
            <div class="weui-tab__panel">
                <div> page1</div>
                <div style="display:none">page2</div>
                <div style="display:none">page3</div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(function(){
        $('.weui-navbar__item').on('click', function () {
            $(this).addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
        });
    });
</script>


</body>  
<script>
      wx.config({
        beta: true,
        debug: false,
        appId: '<?php echo $signPackage["appId"];?>',
        timestamp: <?php echo $signPackage["timestamp"];?>,
        nonceStr: '<?php echo $signPackage["nonceStr"];?>',
        signature: '<?php echo $signPackage["signature"];?>',
        jsApiList: [
          'hideMenuItems',
          ]
        });
      wx.ready(function() {
        wx.hideOptionMenu();
      });
      wx.error(function(res) {
        alert("打开错误");
      });
</script>
</html>  