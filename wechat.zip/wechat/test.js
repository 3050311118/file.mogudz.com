var express = require('express');
var bodyParser = require('body-parser');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();


//var morgan = require('morgan');
var app = express();
var server = require('http').createServer(app);

app.post('/json', function (req, res) {
  req.rawBody = '';
  req.on('data', function(chunk) { 
    req.rawBody += chunk;
  });
  req.on('end', function() {
  	console.log(req.rawBody)
  });	
});

var PORT = process.env.PORT || 8002;
server.listen(PORT);