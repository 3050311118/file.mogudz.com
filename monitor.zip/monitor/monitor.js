var redis = require("redis");
var mqtt = require('mqtt');
var request = require('request');
var nodemailer = require("nodemailer");
var mongodb = require('mongodb');
var mysql = require('mysql');
var fs = require('fs');  

var ALARM_MAX=3
//报警次数
var redisAlarmCount=0;
var mongodbAlarmCount=0;
var mysqlAlarmCount=0;
var mqttAlarmCount=0;
var wechatAlarmCount=0;

// // redis监控
// var redisClient = redis.createClient();
// redisClient.on('ready',function(err){
//   redisAlarmCount=0;
//   var alarmStr=getDateTime()+':  redisClient ready'
//   console.log(alarmStr);
//   filelog(alarmStr)
// });
// redisClient.on("error", function (err) {
//   redisAlarmCount = redisAlarmCount+1
//   if(redisAlarmCount<ALARM_MAX){
//     var alarmStr=getDateTime()+":  redisClient Error " + err
//     console.log(alarmStr);
//     filelog(alarmStr)
//     MailSend("服务器故障","redis错误")
//   }
// });
//mqtt监控
var mqttClient = mqtt.connect({ port: 2568, host: 'www.mogudz.com', keepalive: 10000});   
mqttClient.on('connect', function () {
  mqttAlarmCount=0;
  var alarmStr=getDateTime()+":  mqttjs connected"
  console.log(alarmStr);
  filelog(alarmStr)
});
mqttClient.on('close',function(){
  mqttAlarmCount = mqttAlarmCount+1
  if(mqttAlarmCount<ALARM_MAX){
    var alarmStr=getDateTime()+":  mqttjs 关闭"
    console.log(alarmStr);
    filelog(alarmStr)
    MailSend("服务器故障","mqtt 关闭")
  }  
}); 
mqttClient.on('offline',function(){

}); 
mqttClient.on('error',function(){
  mqttAlarmCount = mqttAlarmCount+1
  if(mqttAlarmCount<ALARM_MAX){
    console.log(getDateTime()+":  mqttjs 错误");
    filelog(alarmStr)
    MailSend("服务器故障","mqtt错误")
  }
}); 

// mongodb监控
// var mongodbServer;
// var mongoClient;

// mongodbServer = new mongodb.Server('localhost', 27017, { auto_reconnect: true, poolSize: 10 });
// mongodbClient = new mongodb.Db('account', mongodbServer);
// mongoDataClient = new mongodb.Db('data', mongodbServer);

function WechatMonitor(){
  var options = {
    method: 'GET',
    url: 'http://www.moguzn.com/monitor'
  };
  request(options, function (err, res, body) {
      if(err){
        wechatAlarmCount = wechatAlarmCount+1
        if(wechatAlarmCount<ALARM_MAX){
          var alarmStr=getDateTime()+":  wechaterror"
          console.log(alarmStr);
          filelog(alarmStr)
          MailSend("服务器故障","wechat错误")
        }      
      }else{
        wechatAlarmCount=0;
      }
  });  
}
setInterval(WechatMonitor,5000);

var mailTransport;
mailTransport = nodemailer.createTransport({
    host: "smtp.163.com",
    secureConnection: false, 
    port: 25, 
    auth: {
        user: "a3050311118@163.com",
        pass: "a4752386"
    }
});


function MailSend(subject,content){
  var mailOptions = {
    from: 'a3050311118@163.com ', // sender address
    to: '15268026301@139.com', // list of receivers
    subject: subject, // Subject line
    html: "时间:"+getDateTime()+"<br>"+content + '<br><a href="http://www.w3school.com.cn">W3School</a>'
  };
  mailTransport.sendMail(mailOptions, function(error, info){
      if(error){
          console.log(error);
      }else{
          console.log('Message sent: ' + info.response);
      }
  });
}

function getDateTime(){
  return new Date().toLocaleString()
}
function filelog(str){
  var time=new Date().toLocaleDateString()
  fs.appendFile(time+".log", str+'\r\n', function(err){  
 
  });   
}
 
